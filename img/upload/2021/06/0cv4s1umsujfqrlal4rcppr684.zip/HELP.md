# 问题

多线程操作时，进入到这个方法， 后续线程`sharedLock.wait();`等待，但是为什么会抛出`InterruptedException`。
我排查了上下文，没有发现任何线程去中断这个线程（也可能是我知识面不够，没注意到）

## 异常结果

```log
2021-06-11 15:17:37.994 ERROR 23976 --- [enerate-match-1] freemarker.runtime                       : Error executing FreeMarker template

freemarker.core._TemplateModelException: Java method "static com.example.demo.kit.BigDecimalUtil.add(java.math.BigDecimal, double)" threw an exception; see cause exception in the Java stack trace.

----
FTL stack trace ("~" means nesting-related):
	- Failed at: ${BigDecimalUtil.min(BigDecimalUtil.a...  [in template "MyTemplate.ftl" at line 2, column 13]
----
	at freemarker.ext.beans._MethodUtil.newInvocationTemplateModelException(_MethodUtil.java:292) ~[freemarker-2.3.31.jar:2.3.31]
	at freemarker.ext.beans._MethodUtil.newInvocationTemplateModelException(_MethodUtil.java:255) ~[freemarker-2.3.31.jar:2.3.31]
	at freemarker.ext.beans.SimpleMethodModel.exec(SimpleMethodModel.java:78) ~[freemarker-2.3.31.jar:2.3.31]
	at freemarker.core.MethodCall._eval(MethodCall.java:62) ~[freemarker-2.3.31.jar:2.3.31]
	at freemarker.core.Expression.eval(Expression.java:101) ~[freemarker-2.3.31.jar:2.3.31]
	at freemarker.core.ListLiteral.getModelList(ListLiteral.java:98) ~[freemarker-2.3.31.jar:2.3.31]
	at freemarker.core.MethodCall._eval(MethodCall.java:60) ~[freemarker-2.3.31.jar:2.3.31]
	at freemarker.core.Expression.eval(Expression.java:101) ~[freemarker-2.3.31.jar:2.3.31]
	at freemarker.core.DollarVariable.calculateInterpolatedStringOrMarkup(DollarVariable.java:100) ~[freemarker-2.3.31.jar:2.3.31]
	at freemarker.core.DollarVariable.accept(DollarVariable.java:63) ~[freemarker-2.3.31.jar:2.3.31]
	at freemarker.core.Environment.visit(Environment.java:347) [freemarker-2.3.31.jar:2.3.31]
	at freemarker.core.Environment.visit(Environment.java:353) [freemarker-2.3.31.jar:2.3.31]
	at freemarker.core.Environment.process(Environment.java:326) [freemarker-2.3.31.jar:2.3.31]
	at freemarker.template.Template.process(Template.java:383) [freemarker-2.3.31.jar:2.3.31]
	at com.example.demo.cfg.FreeMarkerKit.createFile(FreeMarkerKit.java:75) [classes/:na]
	at com.example.demo.DemoApplicationTests.lambda$template$0(DemoApplicationTests.java:54) [test-classes/:na]
	at java.util.concurrent.FutureTask.run$$$capture(FutureTask.java:266) ~[na:1.8.0_282]
	at java.util.concurrent.FutureTask.run(FutureTask.java) ~[na:1.8.0_282]
	at java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1149) ~[na:1.8.0_282]
	at java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:624) ~[na:1.8.0_282]
	at java.lang.Thread.run(Thread.java:748) ~[na:1.8.0_282]
Caused by: java.lang.RuntimeException: Class inrospection data lookup aborded: java.lang.InterruptedException
	at freemarker.ext.beans.ClassIntrospector.get(ClassIntrospector.java:250) ~[freemarker-2.3.31.jar:2.3.31]
	at freemarker.ext.beans.BeanModel.<init>(BeanModel.java:111) ~[freemarker-2.3.31.jar:2.3.31]
	at freemarker.ext.beans.BeanModel.<init>(BeanModel.java:102) ~[freemarker-2.3.31.jar:2.3.31]
	at freemarker.ext.beans.NumberModel.<init>(NumberModel.java:54) ~[freemarker-2.3.31.jar:2.3.31]
	at freemarker.ext.beans.NumberModel$1.create(NumberModel.java:42) ~[freemarker-2.3.31.jar:2.3.31]
	at freemarker.ext.beans.BeansModelCache.create(BeansModelCache.java:72) ~[freemarker-2.3.31.jar:2.3.31]
	at freemarker.ext.util.ModelCache.getInstance(ModelCache.java:80) ~[freemarker-2.3.31.jar:2.3.31]
	at freemarker.ext.beans.BeansWrapper.wrap(BeansWrapper.java:938) ~[freemarker-2.3.31.jar:2.3.31]
	at freemarker.ext.beans.BeansWrapper.invokeMethod(BeansWrapper.java:1556) ~[freemarker-2.3.31.jar:2.3.31]
	at freemarker.ext.beans.SimpleMethodModel.exec(SimpleMethodModel.java:73) ~[freemarker-2.3.31.jar:2.3.31]
	... 18 common frames omitted
```

## FreeMarker抛出异常的方法
```java
   // Introspection:

    /**
     * Gets the class introspection data from {@link #cache}, automatically creating the cache entry if it's missing.
     * 
     * @return A {@link Map} where each key is a property/method/field name (or a special {@link Object} key like
     *         {@link #CONSTRUCTORS_KEY}), each value is a {@link FastPropertyDescriptor} or {@link Method} or
     *         {@link OverloadedMethods} or {@link Field} (but better check the source code...).
     */
    Map<Object, Object> get(Class<?> clazz) {
        {
            Map<Object, Object> introspData = cache.get(clazz);
            if (introspData != null) return introspData;
        }

        String className;
        synchronized (sharedLock) {
            Map<Object, Object> introspData = cache.get(clazz);
            if (introspData != null) return introspData;

            className = clazz.getName();
            if (cacheClassNames.contains(className)) {
                onSameNameClassesDetected(className);
            }

            while (introspData == null && classIntrospectionsInProgress.contains(clazz)) {
                // Another thread is already introspecting this class;
                // waiting for its result.
                try {
                    sharedLock.wait();
                    introspData = cache.get(clazz);
                } catch (InterruptedException e) {
                    throw new RuntimeException(
                            "Class inrospection data lookup aborded: " + e);
                }
            }
            if (introspData != null) return introspData;

            // This will be the thread that introspects this class.
            classIntrospectionsInProgress.add(clazz);
        }
        try {
            Map<Object, Object> introspData = createClassIntrospectionData(clazz);
            synchronized (sharedLock) {
                cache.put(clazz, introspData);
                cacheClassNames.add(className);
            }
            return introspData;
        } finally {
            synchronized (sharedLock) {
                classIntrospectionsInProgress.remove(clazz);
                sharedLock.notifyAll();
            }
        }
    }
```