package com.example.demo;

import com.example.demo.cfg.FreeMarkerKit;
import org.junit.jupiter.api.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.stream.Collectors;
import java.util.zip.ZipOutputStream;

@SpringBootTest
class DemoApplicationTests {


	private static final Logger log = LoggerFactory.getLogger(DemoApplicationTests.class);

	@Test
	void template() throws IOException {
		// 初始化线程池
		ThreadPoolTaskExecutor executor = new ThreadPoolTaskExecutor();
		executor.setCorePoolSize(4);
		executor.setMaxPoolSize(4);
		executor.setQueueCapacity(10);
		executor.setKeepAliveSeconds(60);
		executor.setThreadNamePrefix("generate-match-");
		executor.setRejectedExecutionHandler(new ThreadPoolExecutor.CallerRunsPolicy());
		executor.initialize();

		File file = new File("test.zip");
		file.deleteOnExit();
		file.createNewFile();
		ZipOutputStream out = new ZipOutputStream(new FileOutputStream(file));
		List<Future<Boolean>> futures = new ArrayList<>();

		// 并发任务，渲染不同文件
		for (int i = 0; i < 10; i++) {
			int index = i;
			Callable<Boolean> job = ()->{
				HashMap<String,Object> map = new HashMap<>();
				if (index == 0) {
					map.put("model", new Entity("",index));
				} else {
					map.put("model", new Entity(String.valueOf(index),index));
				}
				FreeMarkerKit.createFile(map,"MyTemplate.ftl",index+"_Current.txt",out);
				return true;
			};
			Future<Boolean> submit = executor.submit(job);
			futures.add(submit);
		}
		out.finish();
		executor.shutdown();
		// 等待任务结束
		while (!futures.stream().allMatch(Future::isDone)) {
			try {
				wait(1000);
			} catch (Throwable e) {
				log.debug("try wait 1s fail, retry!");
			}
		}
		// 获取任务结果
		futures.stream().map(f -> {
			try {
				return f.get();
			} catch (InterruptedException | ExecutionException e) {
				log.warn("get result data err!",e);
			}
			return false;
		}).collect(Collectors.toSet());
	}
	public class Entity {
		private String rate;
		private BigDecimal val;


		public Entity(String rate, int val) {
			this.rate = rate;
			this.val = new BigDecimal(val);
		}

		public Entity(String rate, BigDecimal val) {
			this.rate = rate;
			this.val = val;
		}

		public String getRate() {
			return rate;
		}

		public void setRate(String rate) {
			this.rate = rate;
		}

		public BigDecimal getVal() {
			return val;
		}

		public void setVal(BigDecimal val) {
			this.val = val;
		}
	}

}
