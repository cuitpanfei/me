package com.example.demo.kit;

import java.math.BigDecimal;

public class BigDecimalUtil {
    public static BigDecimal add(BigDecimal decimal, double augend) {
        return decimal.add(new BigDecimal(augend + ""));
    }

    public static BigDecimal subtract(BigDecimal decimal, double subtrahend) {
        return decimal.subtract(new BigDecimal(subtrahend + ""));
    }

    public static BigDecimal subtract(double value, BigDecimal subtrahend) {
        return new BigDecimal(value + "").subtract(subtrahend);
    }

    public static BigDecimal min(BigDecimal decimal1, BigDecimal decimal2) {
        if (decimal1.compareTo(decimal2) > 0) {
            return decimal1;
        } else {
            return decimal2;
        }
    }
}
