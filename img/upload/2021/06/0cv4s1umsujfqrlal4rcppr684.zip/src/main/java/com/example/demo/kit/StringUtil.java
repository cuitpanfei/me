package com.example.demo.kit;

public class StringUtil {

    /**
     * judge String is empty?
     *
     * @param str The string to be judged
     * @return is empty?
     */
    public static boolean isEmpty(String str) {
        return str == null || str.length() == 0;
    }
}
