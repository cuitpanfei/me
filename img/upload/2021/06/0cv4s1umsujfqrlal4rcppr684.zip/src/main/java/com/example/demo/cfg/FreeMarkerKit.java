package com.example.demo.cfg;

import com.example.demo.kit.BigDecimalUtil;
import com.example.demo.kit.StringUtil;
import freemarker.ext.beans.BeansWrapper;
import freemarker.ext.beans.BeansWrapperBuilder;
import freemarker.template.Configuration;
import freemarker.template.Template;
import freemarker.template.TemplateException;
import freemarker.template.TemplateHashModel;
import freemarker.template.TemplateModelException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.web.servlet.view.freemarker.FreeMarkerConfigurer;

import javax.annotation.PostConstruct;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

@Component
public class FreeMarkerKit {

    private static final Logger log = LoggerFactory.getLogger(FreeMarkerKit.class);

    @Autowired
    private FreeMarkerConfigurer freeMarkerConfigurer;

    private static FreeMarkerKit INSTANCE;
    Map<String, Object> dataModel = new ConcurrentHashMap<>();

    /**
     * 初始化单例引用以及渲染时可能会使用到的静态类
     */
    @PostConstruct
    public void initInstance() {
        INSTANCE = this;
        BeansWrapper wrapper = new BeansWrapperBuilder(Configuration.VERSION_2_3_31).build();
        TemplateHashModel staticModels = wrapper.getStaticModels();
        try {
            TemplateHashModel stringUtil = (TemplateHashModel) staticModels.get(StringUtil.class.getName());
            TemplateHashModel bigDecimalUtil = (TemplateHashModel) staticModels.get(BigDecimalUtil.class.getName());
            dataModel.put("StringUtil", stringUtil);
            dataModel.put("BigDecimalUtil", bigDecimalUtil);
        } catch (TemplateModelException e) {
            log.error("get template failed", e);
        }
    }

    /**
     * 根据模版文件找到模版对象，然后根据模版对象渲染数据，得到渲染结果，将渲染结果写入zip流
     *
     * @param dataModel    data
     * @param templateName templateName eg：06test.ftl
     * @param fullFilePath file path in ZipOutputStream
     * @param zos          stream
     */
    public static void createFile(HashMap<String, Object> dataModel, String templateName, String fullFilePath,
                                  ZipOutputStream zos) {
        Template template;
        try {
            template = INSTANCE.freeMarkerConfigurer.getConfiguration().getTemplate(templateName);
        } catch (IOException e) {
            log.error("get template failed", e);
            return;
        }
        dataModel.putAll(INSTANCE.dataModel);
        try (ByteArrayOutputStream arrayOutputStream = new ByteArrayOutputStream();
             OutputStreamWriter writer = new OutputStreamWriter(arrayOutputStream)) {
            template.process(dataModel, writer);
            byte[] fileBytes = arrayOutputStream.toByteArray();
            zos.putNextEntry(new ZipEntry(fullFilePath));
            zos.write(fileBytes, 0, fileBytes.length);
            writer.flush();
        } catch (TemplateException | IOException e) {
            log.error("template process failed", e);
        }


    }
}
