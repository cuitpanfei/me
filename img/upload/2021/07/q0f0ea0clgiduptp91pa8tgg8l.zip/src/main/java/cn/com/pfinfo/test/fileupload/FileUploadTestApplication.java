package cn.com.pfinfo.test.fileupload;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

@RestController
@RequestMapping
@SpringBootApplication
public class FileUploadTestApplication {

	@PostMapping(consumes = MediaType.MULTIPART_FORM_DATA_VALUE, produces =
			MediaType.APPLICATION_JSON_VALUE)
	public String uploadFile(MultipartFile file){
		System.out.println("request start: file.isEmpty="+file.isEmpty());
		new Thread(()->{
			try {
				Thread.sleep(1000);
				// why file is empty?
				System.out.println("detail request: file.isEmpty="+file.isEmpty());
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}).start();
		System.out.println("request end: file.isEmpty="+file.isEmpty());
		return "{\"msg\":\"success!\"}";
	}

	public static void main(String[] args) {
		SpringApplication.run(FileUploadTestApplication.class, args);
	}

}
