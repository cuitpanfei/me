package cn.com.pfinfo.test.fileupload;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.core.io.FileSystemResource;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestTemplate;

import java.io.File;

@SpringBootTest
class FileUploadTestApplicationTests {

	@Test
	void testUpload() {
		RestTemplate client  = new RestTemplate();
		String url = "http://localhost:8080/";
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.MULTIPART_FORM_DATA);
		MultiValueMap<String, Object> params= new LinkedMultiValueMap<>();
		params.add("file", new FileSystemResource(new File("pom.xml")));
		HttpEntity<MultiValueMap<String, Object>> entity = new HttpEntity<>(params, headers);
		ResponseEntity<String> response = client.exchange(url, HttpMethod.POST, entity, String.class);
		System.out.println(response.getBody());
	}

}
